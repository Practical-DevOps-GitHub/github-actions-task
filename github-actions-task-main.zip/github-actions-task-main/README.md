# Github Actions Task

You will need to install all the dependencies that is needed for this project using npm.
Then you have to pass all of the tests in application and build it into the git actions workflow.



# To install dependencies

npm ci

# To run the test

npm test

# To build the application

npm run build